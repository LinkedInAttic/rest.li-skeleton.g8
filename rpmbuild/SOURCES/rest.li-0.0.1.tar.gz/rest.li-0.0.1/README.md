Rest.li Command Line Tool
=========================

